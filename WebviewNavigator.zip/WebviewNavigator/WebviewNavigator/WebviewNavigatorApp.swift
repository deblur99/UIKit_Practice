//
//  WebviewNavigatorApp.swift
//  WebviewNavigator
//
//  Created by 한현민 on 2023/08/03.
//

import SwiftUI

@main
struct WebviewNavigatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
